window.onload=function(){
    // 获取元素
    var banner = document.querySelector(".banner")
    var ulimg = document.querySelector(".ulimg")
    var point=banner.querySelector(".point")
   // 复制第一张和最后一张,动态添加
    imgfirst=ulimg.querySelector("li:first-of-type")
    imglast=ulimg.querySelector("li:last-of-type")
    ulimg.appendChild(imgfirst.cloneNode(true))
    ulimg.insertBefore(imglast.cloneNode(true),imgfirst)
    // 只返回第一个li
    // var lis1 = ulimg.querySelector("li")
    // var lis2 = point.querySelector("li")
    var lis1 = ulimg.querySelectorAll("li")
    var lis2 = point.querySelectorAll("li")
    console.log(lis1)
    // 设置宽度,重新设置每个ulimg和li的宽度，他们的宽度都是和bannerwidth与li的个数有关，不是原来的12.5%---是10%
    console.log(ulimg.offsetWidth)

    var bannerwidth = banner.offsetWidth
    console.log(bannerwidth)
    var length1 = lis1.length;
    console.log(length1)
    var imgwidth = length1*bannerwidth
    //offsetWidth设置无效只能获取值，设置width
    ulimg.style.width=imgwidth+"px"
    for(var i = 0;i<lis1.length;i++){
        lis1[i].style.width = bannerwidth + "px";
    }
    // 前提：ulimg定位才能设置偏移
    ulimg.style.left=-bannerwidth+"px"
    // 屏幕变化重新设置宽度
   window.onresize=function(){
    bannerwidth=banner.offsetWidth;
    ulimg.style.width=length1*bannerwidth+"px"
    for(var i = 0;i<lis1.length;i++){
        lis1[i].style.width = bannerwidth + "px";
    }
    ulimg.style.left=-bannerwidth+"px"

   }
    //第二步实现自动轮播
      var index = 1
    var startime = function(){
        timeid=setInterval(function(){
         index++;
          ulimg.style.transition="left 0.5s linear"
          ulimg.style.left=(-index*bannerwidth)+"px"

          setTimeout(function(){
            // 如果滑倒最后一张实质是第一张，瞬间使index=1，跳到真实第一张，去除滑动效果
                if(index==length1-1){
                    index=1
                    ulimg.style.transition="none";
                    ulimg.style.left=(-index*bannerwidth)+"px";
                }

             },500)
        },2000)
      
    }
    startime();


    // 手动轮播,此时上面计时器停止，index的值要通过touch事件来变化，不然每次滑动index还是原来那个，位置每次滑动都不变
    var startx,movex,distancex;
    ulimg.addEventListener("touchstart",function(e){
      clearInterval(timeid);
      startx=e.touches[0].clientX;

    })
    ulimg.addEventListener("touchmove",function(e){
        movex=e.touches[0].clientX;
        distancex=movex-startx;
        ulimg.style.transition="none";
        ulimg.style.left=-index*bannerwidth+distancex+"px";
        
    })
    ulimg.addEventListener("touchend",function(e){
        if(Math.abs(distancex)>100){
            if(distancex>0){
                index--
            }else{
                index++
            }
            ulimg.style.transition="left 0.5s linear"
            ulimg.style.left=-index*bannerwidth+"px"
        }else if(Math.abs(distancex)>0){
            ulimg.style.transition="left 0.5s linear"
            ulimg.style.left=-index*bannerwidth+"px"
        }
        // 原来计时器清楚了，需要再次调用函数制造定时器
        startime()
        // timeid()

        // 解决bug：不断拖动直到直到最后一张，整个ulimg不见了，我们在手动轮播还没有限制index的值，index=9>index=1,index=0>index=8
        // 前提每一次过度效果执行完毕，每一次被webkitTransitionEnd检测到，立flag,使得没有执行完毕不允许下一次偏移
         ulimg.addEventListener("webkitTransitionEnd",function(){
             if(index==length1-1){
                 index=1
                 ulimg.style.transition="none"
                 ulimg.style.left=-index*bannerwidth+"px"
             }else if(index==0){
                 index=length1-2;
                 ulimg.style.transition="none"
                 ulimg.style.left=-index*bannerwidth+"px"
             }
         })

    })
     

}